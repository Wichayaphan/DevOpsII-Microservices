from flask import Flask, request, jsonify
import datetime
# pip install Flask-JWT
# import jwt
import data_user as us

app = Flask(__name__)

@app.route('/update/<productname>', methods=['POST'])
def update(productname):
    # Get the user's login information from the request
    category = request.form.get('category')
    price = request.form.get('price')
    instock = request.form.get('instock')
    name = request.form.get('productname')

    _user = us.find_username(productname)
    data = [x for x in _user if x["name"]== productname]
    # return jsonify(_user)
    #Get Data
    if data:
        us.user_name_update(category,price,instock,name)
        return jsonify({'message': 'Updated successfully.'}), 200
    else:
        return jsonify({'message': 'Cannot update product.'}), 404
    

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5004, debug=True) #127.0.0.1