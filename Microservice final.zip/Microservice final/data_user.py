import sqlite3
import os

#File and path for database
db_folder = os.path.join(os.path.dirname(__file__), "db_product.db")

def user_name():
    data = []
    conn = sqlite3.connect(db_folder)
    sql = """
        SELECT category, price, instock, name
        FROM username 
        ORDER BY name
    """
    cursor = conn.execute(sql)
    rows = cursor.fetchall()

    for row in rows:
        record = {
            'category': row[0],
            'price': row[1],
            'instock' : row[2],
            'name': row[3]
            }
        data.append(record)
    
    conn.close()
    return data

def find_username(user):
    data = []
    conn = sqlite3.connect(db_folder)
    sql = """
        SELECT category, price, instock, name
        FROM username 
        WHERE name=?
    """
    val = (user,)
    cursor = conn.execute(sql,val)
    rows = cursor.fetchone()

    record = {
        'category': rows[0],
        'price': rows[1],
        'instock' : rows[2],
        'name': rows[3]
        }
    data.append(record)
    
    conn.close()
    return data

def user_name_add(category,price,instock,name):
    conn = sqlite3.connect(db_folder)
    sql = """
        INSERT INTO username(category,price,instock,name)
        VALUES(?,?,?,?)
    """
    val = (category,price,instock,name)
    cursor = conn.execute(sql, val)
    conn.commit()
    conn.close()
    return "Created successfully"

def user_name_delete(name):
    conn = sqlite3.connect(db_folder)
    sql = """
        DELETE FROM username
        WHERE name = ?
    """
    val = (name,)
    cursor = conn.execute(sql, val)
    conn.commit()
    conn.close()
    return "Deleted successfully"

def user_name_update(category,price,instock,name):
    conn = sqlite3.connect(db_folder)
    sql = """
        UPDATE username
        SET category = ?, price = ?,instock = ?, name = ?
        WHERE name = ?
    """
    val = (category,price,instock,name,name)
    conn.execute(sql, val)
    conn.commit()
    conn.close()
    return "Updated successfully"